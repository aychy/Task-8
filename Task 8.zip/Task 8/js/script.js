function getData() {

    axios.get('https://jsonplaceholder.typicode.com/photos').then(resp => {
    
    
    
    resp.data.slice(1, 10).forEach(element => {
    
    
    
    $("#tasks").html($("#tasks").html() + `
    
    <div>
    
    <img src="${element.url}" height="300" alt="${element.title}" />
    
    <p>${element.title}</p>
    
    </div>
    
    `)
    
    });
    
    });
    
    }
    
    